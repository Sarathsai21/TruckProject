package com.capgemini.truckbooking.exceptions;

public class TruckBookingException extends Exception{
	
	public TruckBookingException(String message) {
		
		super(message);
		
	}

}
